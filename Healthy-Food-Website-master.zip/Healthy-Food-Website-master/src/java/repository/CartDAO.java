/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

/**
 *
 * @author DELL
 */
import model.cart;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Vector;
import java.util.List;
import java.util.ArrayList;

public class CartDAO extends DBContext {

    public cart getCart(int productID, int quantity) {
        cart cart = null;
        String sql = "SELECT \n"
                + "    c.CartID, \n"
                + "    c.ProductID, \n"
                + "    p.ProductName, \n"
                + "    p.Price, \n"
                + "    c.Quantity\n"
                + "FROM \n"
                + "    Cart c\n"
                + "JOIN \n"
                + "    Products p ON c.ProductID = p.ProductID\n"
                + "WHERE \n"
                + "    c.ProductID = ?;" ;
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, productID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                cart = new cart(
                    rs.getInt("CartID"),
                    rs.getInt("ProductID"),
                    rs.getString("ProductName"),
                    rs.getInt("Price"),
                    quantity  // Use the provided quantity
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cart;
    }

    public boolean updateCartQuantity(List<cart> cartItems, int productID, int newQuantity) {
        // Update in session cart
        if (cartItems != null) {
            for (cart item : cartItems) {
                if (item.getProductID() == productID) {
                    item.setQuantity(newQuantity);
                    return true;
                }
            }
        }
        return false;
    }

    public boolean removeCartItem(List<cart> cartItems, int productID) {
        // Remove from session cart
        if (cartItems != null) {
            for (int i = 0; i < cartItems.size(); i++) {
                if (cartItems.get(i).getProductID() == productID) {
                    cartItems.remove(i);
                    return true;
                }
            }
        }
        return false;
    }

    public List<cart> getCartByUserID(int userID) {
        List<cart> cartItems = new ArrayList<>();
        String sql = "SELECT CartID, UserID, ProductID, ProductName, Price, Quantity " +
                    "FROM Cart " +
                    "WHERE UserID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, userID);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                cart item = new cart(
                    rs.getInt("CartID"),
                    rs.getInt("ProductID"),
                    rs.getString("ProductName"),
                    rs.getInt("Price"),
                    rs.getInt("Quantity")
                );
                cartItems.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cartItems;
    }

    public boolean updateCartQuantity(int cartID, int newQuantity) {
        String sql = "UPDATE Cart SET Quantity = ? WHERE CartID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, newQuantity);
            ps.setInt(2, cartID);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean removeCartItem(int cartID) {
        String sql = "DELETE FROM Cart WHERE CartID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, cartID);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addToCart(int userID, int productID, String productName, int price, int quantity) {
        String sql = "INSERT INTO Cart (UserID, ProductID, ProductName, Price, Quantity) " +
                    "VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setInt(1, userID);
            ps.setInt(2, productID);
            ps.setString(3, productName);
            ps.setInt(4, price);
            ps.setInt(5, quantity);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Test method to add sample cart items
    public void addTestCartItems() {
        // First, clear any existing test items for user 3 (Customer One)
        String deleteSql = "DELETE FROM Cart WHERE UserID = 3";
        try {
            PreparedStatement deletePs = connection.prepareStatement(deleteSql);
            deletePs.executeUpdate();
            
            // Add test items for Customer One (UserID = 3)
            String insertSql = "INSERT INTO Cart (UserID, ProductID, ProductName, Price, Quantity) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertPs = connection.prepareStatement(insertSql);
            
            // Test Item 1: Fresh Spring Rolls
            insertPs.setInt(1, 3); // UserID
            insertPs.setInt(2, 1); // ProductID
            insertPs.setString(3, "Fresh Spring Rolls");
            insertPs.setInt(4, 50000); // Price
            insertPs.setInt(5, 2); // Quantity
            insertPs.executeUpdate();
            
            // Test Item 2: Chicken Salad Wrap
            insertPs.setInt(1, 3);
            insertPs.setInt(2, 2);
            insertPs.setString(3, "Chicken Salad Wrap");
            insertPs.setInt(4, 60000);
            insertPs.setInt(5, 1);
            insertPs.executeUpdate();
            
            // Test Item 3: Avocado Salad
            insertPs.setInt(1, 3);
            insertPs.setInt(2, 5);
            insertPs.setString(3, "Avocado Salad");
            insertPs.setInt(4, 50000);
            insertPs.setInt(5, 3);
            insertPs.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to test cart functionality
    public void testCart() {
        // Add test items
        addTestCartItems();
        
        // Get and display cart items
        List<cart> cartItems = getCartByUserID(3);
        System.out.println("Test Cart Items for User 3:");
        for (cart item : cartItems) {
            System.out.println("Product: " + item.getProductName() + 
                             ", Price: " + item.getPrice() + 
                             ", Quantity: " + item.getQuantity());
        }
    }
}
