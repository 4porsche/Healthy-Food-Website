package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import repository.CartDAO;
import repository.OrderDAO;
import model.cart;
import model.order;
import model.orderdetail;
import java.io.IOException;
import java.util.List;
import java.util.Date;

@WebServlet(name = "ProcessCheckout", urlPatterns = {"/jsp/processcheckout"})
public class ProcessCheckout extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();
        Integer userID = (Integer) session.getAttribute("userID");
        
        // For testing, use userID 3 if not logged in
        if (userID == null) {
            userID = 3; // Set to Customer One for testing
        }
        
        try {
            // Get cart items
            CartDAO cartDAO = new CartDAO();
            List<cart> cartItems = cartDAO.getCartByUserID(userID);
            
            if (cartItems == null || cartItems.isEmpty()) {
                session.setAttribute("checkoutMessage", "Your cart is empty!");
                response.sendRedirect("cart.jsp");
                return;
            }
            
            // Get form data
            String fullName = request.getParameter("fullName");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");
            String city = request.getParameter("city");
            String notes = request.getParameter("notes");
            String paymentMethod = request.getParameter("paymentMethod");
            
            // Calculate totals
            double subTotal = 0;
            for (cart item : cartItems) {
                subTotal += item.getPrice() * item.getQuantity();
            }
            double shippingCost = 10000.0; // Fixed shipping cost
            double total = subTotal + shippingCost;
            
            // Create order
            OrderDAO orderDAO = new OrderDAO();
            order newOrder = new order();
            newOrder.setUserID(userID);
            newOrder.setOrderDate(new Date());
            newOrder.setTotalAmount(total);
            newOrder.setStatus("Pending");
            newOrder.setShippingAddress(address + ", " + city);
            newOrder.setPhone(phone);
            newOrder.setEmail(email);
            newOrder.setNotes(notes);
            newOrder.setPaymentMethod(paymentMethod);
            
            // Save order and get order ID
            int orderID = orderDAO.createOrder(newOrder);
            
            if (orderID > 0) {
                // Create order details
                for (cart item : cartItems) {
                    orderdetail detail = new orderdetail();
                    detail.setOrderID(orderID);
                    detail.setProductID(item.getProductID());
                    detail.setQuantity(item.getQuantity());
                    detail.setPrice(item.getPrice());
                    orderDAO.addOrderDetail(detail);
                }
                
                // Clear cart after successful order
                cartDAO.clearCart(userID);
                
                // Set success message
                session.setAttribute("orderMessage", "Order placed successfully! Order ID: " + orderID);
                response.sendRedirect("order-confirmation.jsp?orderId=" + orderID);
            } else {
                session.setAttribute("checkoutMessage", "Failed to create order. Please try again.");
                response.sendRedirect("checkout.jsp");
            }
            
        } catch (Exception e) {
            session.setAttribute("checkoutMessage", "An error occurred: " + e.getMessage());
            response.sendRedirect("checkout.jsp");
        }
    }
} 