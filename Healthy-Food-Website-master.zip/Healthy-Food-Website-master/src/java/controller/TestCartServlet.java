package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import repository.CartDAO;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "TestCartServlet", urlPatterns = {"/testcart"})
public class TestCartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // Set user ID in session for testing
            HttpSession session = request.getSession();
            session.setAttribute("userID", 3); // Set Customer One as logged in user
            
            CartDAO cartDAO = new CartDAO();
            
            // Add test items
            cartDAO.addTestCartItems();
            
            // Display test results
            out.println("<html><body>");
            out.println("<h2>Cart Test Results</h2>");
            out.println("<p>Test cart items have been added for User ID 3 (Customer One)</p>");
            out.println("<p>Items added:</p>");
            out.println("<ul>");
            out.println("<li>Fresh Spring Rolls (2 x 50,000 VND)</li>");
            out.println("<li>Chicken Salad Wrap (1 x 60,000 VND)</li>");
            out.println("<li>Avocado Salad (3 x 50,000 VND)</li>");
            out.println("</ul>");
            out.println("<p>Total items: 6</p>");
            out.println("<p>Total value: 310,000 VND</p>");
            out.println("<p><a href='jsp/cart.jsp'>View Cart</a></p>");
            out.println("</body></html>");
            
        } catch (Exception e) {
            out.println("<html><body>");
            out.println("<h2>Error</h2>");
            out.println("<p>Error during cart test: " + e.getMessage() + "</p>");
            out.println("</body></html>");
        }
    }
} 